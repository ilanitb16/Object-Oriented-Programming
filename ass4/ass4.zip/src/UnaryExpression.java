// 322453200 Ilanit Berditchevski.
/**
 * Class representing UnaryExpression.
 *
 */
public class UnaryExpression extends BaseExpression {
    /**
     * Constructor UnaryExpression.
     * @param expression expression
     */
    public UnaryExpression(Expression expression) {
        super(expression);
    }

}
